package com.ssafy.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.MemberDto;

@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		
		String act = request.getParameter("act");
		
		if("mvlogin".equals(act)) {
			response.sendRedirect(root + "/user/login.jsp");
		} else if("login".equals(act)) {
			login(request, response);
		} else if("logout".equals(act)) {
			logout(request, response);
		} else if("mvwrite".equals(act)) {
			response.sendRedirect(root + "/product/write.jsp");
		} else if("write".equals(act)) {
			addProduct(request, response);
		}  else if("success".equals(act)) {
			response.sendRedirect(root + "/product/success.jsp");
		} else {
			response.sendRedirect(root);
		}
	}

	private void addProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");
		if(memberDto != null) {
//				cookie 설정
			Cookie cookieNo = new Cookie("productno", request.getParameter("productno"));
			Cookie cookieName = new Cookie("productName", request.getParameter("productName"));
			Cookie cookiePrice = new Cookie("price", request.getParameter("price"));
			Cookie cookieDesc = new Cookie("description", request.getParameter("description"));
			
			cookieNo.setPath(request.getContextPath());
			cookieName.setPath(request.getContextPath());
			cookiePrice.setPath(request.getContextPath());
			cookieDesc.setPath(request.getContextPath());
			
			cookieNo.setMaxAge(60 * 60 * 24 * 365);
			cookieName.setMaxAge(60 * 60 * 24 * 365);
			cookiePrice.setMaxAge(60 * 60 * 24 * 365);
			cookieDesc.setMaxAge(60 * 60 * 24 * 365);
			
			response.addCookie(cookieNo);
			response.addCookie(cookieName);
			response.addCookie(cookiePrice);
			response.addCookie(cookieDesc);
			
//			path = "/product/success.jsp";
		} else {
			request.setAttribute("msg", "로그인 후 사용 가능한 페이지입니다.");
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		session.removeAttribute("userinfo");
//		session.invalidate();
		response.sendRedirect(request.getContextPath());
	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		
		if(userid.equals("ssafy") && userpwd.equals("ssafy")) {
			MemberDto memberDto = new MemberDto(userid, userpwd);
//				session 설정
			HttpSession session = request.getSession();
			session.setAttribute("userinfo", memberDto);
		} else {
			request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 로그인해 주세요.");
		}
		
		request.getRequestDispatcher(path).forward(request, response);
	}
	
}
