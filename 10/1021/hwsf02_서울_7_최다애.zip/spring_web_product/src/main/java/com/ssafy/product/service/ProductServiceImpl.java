package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dto.Product;

@Service("productService")
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductDao dao;
	
	public List<Product> searchAll() {
		return dao.searchAll();
	}
	public Product search(String id) {
		return dao.search(id);
	}
	public void insert(Product product) {
		dao.insert(product);
	}
	public void update(Product product) {
		dao.update(product);
	}
	public void delete(String id) {
		dao.delete(id);
	}
}
