package com.ssafy.hw.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ssafy.hw.configuration.ApplicationConfig;
import com.ssafy.hw.model.dto.Product;
import com.ssafy.hw.model.service.ProductService;
import com.ssafy.hw.model.service.ProductServiceImpl;

public class BeanTest {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		
		ProductService productService = context.getBean("pdService", ProductServiceImpl.class);
		
		Product product = new Product();
		product.setId("1234");
		product.setName("상품1");
		product.setPrice(10000);
		product.setDescription("좋은 상품입니다.");
		

		try {
			productService.getRepo();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			productService.insert(product);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			productService.selectAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String id = "1111";
		try {
			productService.select(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			productService.delete(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			productService.update(product);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
