package com.ssafy.hw.model.service;

import java.util.List;

import com.ssafy.hw.model.dto.Product;
import com.ssafy.hw.model.repository.ProductRepo;

public interface ProductService {
	public ProductRepo getRepo() throws Exception;
	public List<Product> selectAll() throws Exception;
	public Product select(String id) throws Exception;
	public int insert(Product product) throws Exception;
	public int update(Product product) throws Exception;
	public int delete(String id) throws Exception;
}
