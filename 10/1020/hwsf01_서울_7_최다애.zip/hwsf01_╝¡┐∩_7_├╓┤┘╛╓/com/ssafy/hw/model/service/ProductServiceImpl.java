package com.ssafy.hw.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.hw.model.dto.Product;
import com.ssafy.hw.model.repository.ProductRepo;

@Service(value = "pdService")
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepo productRepo;

	@Override
	public ProductRepo getRepo() {
		return productRepo;
	}

	@Override
	public List<Product> selectAll()  throws Exception{
		return productRepo.selectAll();
	}

	@Override
	public Product select(String id)  throws Exception{
		return productRepo.select(id);
	}

	@Override
	public int insert(Product product)  throws Exception{
		return productRepo.insert(product);
	}

	@Override
	public int update(Product product)  throws Exception{
		return productRepo.update(product);
	}

	@Override
	public int delete(String id)  throws Exception{
		return productRepo.delete(id);
	}

}
