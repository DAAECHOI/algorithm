package com.ssafy.hw.model.repository;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.hw.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {

	@Autowired
	private DataSource dataSource;
	
	@Override
	public List<Product> selectAll() throws SQLException{
		System.out.println("selectAll 완료");
		return null;
	}

	@Override
	public Product select(String id) throws SQLException{
		System.out.println("select 완료");
		return null;
	}

	@Override
	public int insert(Product product) throws SQLException{
		System.out.println("insert 완료");
		return 0;
	}

	@Override
	public int update(Product product) throws SQLException{
		System.out.println("update 완료");
		return 0;
	}

	@Override
	public int delete(String id) throws SQLException{
		System.out.println("delete 완료");
		return 0;
	}

}
