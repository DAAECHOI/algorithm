import Vue from "vue";
import VueRouter from "vue-router";
import List from "../components/List.vue";
import Register from "../components/Register.vue";
import Remove from "../components/Remove.vue";
import Detail from "../components/Detail.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/list",
    name: "list",
    component: List
  },
  {
    path: "/register",
    name: "register",
    component: Register
  },
  {
    path: "/remove",
    name: "remove",
    component: Remove
  },
  {
    path: "/detail",
    name: "detail",
    component: Detail
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
