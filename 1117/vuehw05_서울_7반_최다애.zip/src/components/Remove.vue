<template>
    <div id="app" class='container'>
        <h2 class='text-center'>퇴사 처리중 입니다.</h2>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    methods : {
        moveHandler : function(){
            this.$router.push('/list')
        }
    },
    created(){
        const params = new URL(document.location).searchParams;
        if(confirm('정말로 퇴사 처리하시겠습니까?')){
            axios
            .delete(`http://localhost:8097/hrmboot/api/employee/${params.get('id')}`)
            .then(() => {
                alert("사원의 퇴사가 완료되었습니다.");
                this.moveHandler();
            })
            .catch(error => {
                alert(error);
                this.moveHandler();
            });
        }
    }
}
</script>