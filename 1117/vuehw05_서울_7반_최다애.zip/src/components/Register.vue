<template>
    <div id="app" class='container'>
        <h2 class='text-center'>사원 등록</h2>
        <table class='table table-boarded table-condensed'>
            <colgroup>
                <col width='20%'/>
                <col width='20%'/>
                <col width='20%'/>
                <col width='20%'/>
                <col width='20%'/>
            </colgroup>
            <tr>
                <th>사원명</th>
                <td>
                    <input type="text" id="name" v-model="name" ref="name" placeholder="사원명을 입력해주세요"/>
                </td>
            </tr>
            <tr>
                <th>이메일</th>
                <td>
                    <input type="text" id="mailid" v-model="mailid" ref="mailid" placeholder="이메일을 입력해주세요"/>
                </td>
            </tr>
            <tr>
                <th>고용일</th>
                <td>
                    <input type="date" id="startDate" v-model="startDate" ref="startDate"/>
                </td>
            </tr>
            <tr>
                <th>관리자</th>
                <td>
                    <input type="text" id="managerId" v-model="managerId" ref="managerId" placeholder="관리자를 입력해주세요"/>
                </td>
            </tr>
            <tr>
                <th>직책</th>
                <td>
                    <select v-model="title" ref="title" id="title">
                        <option value="사장">사장</option>
                        <option value="기획부장">기획부장</option>
                        <option value="영업부장">영업부장</option>
                        <option value="총무부장">총무부장</option>
                        <option value="인사부장">인사부장</option>
                        <option value="과장">과장</option>
                        <option value="영업대표이사">영업대표이사</option>
                        <option value="사원">사원</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th>부서</th>
                <td>
                    <input type="text" id="deptId" v-model="deptId" ref="deptId" placeholder="부서를 입력해주세요"/>
                </td>
            </tr>
            <tr>
                <th>연봉</th>
                <td>
                    <input type="text" id="salary" v-model="salary" ref="salary" placeholder="연봉을 입력해주세요"/>
                </td>
            </tr>
            <tr>
                <th>커미션</th>
                <td>
                    <input type="text" id="commission" v-model="commission" ref="commission" placeholder="커미션을 입력해주세요"/>
                </td>
            </tr>
        </table>
        <div class="text-right">
            <button class="btn btn-primary" @click="registerHandler">등록</button>
            <button class="btn btn-primary" @click="moveHandler">목록</button>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            name: '',
            mailid: '',
            startDate: '',
            managerId: '',
            title: '',
            deptId: '',
            salary: '',
            commission: ''
        }
    },
    methods : {
        moveHandler : function(){
            this.$router.push('/list')
        },
        registerHandler : function(){
            let err = true;
            let msg = '';
            //필수 요건 검사
            !this.name &&
                ((msg = '사원명을 입력해 주세요'),
                (err = false));
            err &&
                !this.mailid &&
                ((msg = '이메일을 입력해 주세요'),
                (err = false));
            err &&
                !this.managerId &&
                ((msg = '관리자를 입력해 주세요'),
                (err = false));
            err &&
                !this.deptId &&
                ((msg = '부서를 입력해 주세요'),
                (err = false));
            err &&
                !this.salary &&
                ((msg = '연봉을 입력해 주세요'),
                (err = false));

            if (!err) alert(msg);
            else {
                axios
                .post('http://localhost:8097/hrmboot/api/employee', {
                    name: this.name,
                    mailid: this.mailid,
                    start_date: this.startDate,
                    manager_id: this.managerId,
                    dept_id: this.deptId,
                    title: this.title,
                    salary: this.salary,
                    commission_pct: this.commission
                })
                .then(() => {
                    alert("사원 등록이 완료되었습니다.");
                    this.moveHandler();
                })
                .catch(error => {
                    alert(error);
                });
            }
        }
    }
}
</script>