<template>
    <div id="app" class='container'>
        <h2 class='text-center'>사원 목록</h2>
        <div class="text-right">
            <button class="btn btn-primary" @click="movePage">등록</button>
        </div>
        <div class="text-center">
            <input type="text" id="sname" v-model="sname">
            <button class="btn btn-primary" @click="searchEmp">검색</button>
        </div>
        <div v-if="emps.length">
            <table class='table table-boarded table-condensed'>
                <colgroup>
                    <col width='20%'/>
                    <col width='20%'/>
                    <col width='20%'/>
                    <col width='20%'/>
                    <col width='20%'/>
                </colgroup>
                <tr>
                    <td>사원 아이디</td>                    
                    <td>사원명</td>                    
                    <td>부서</td>                    
                    <td>직책</td>                    
                    <td>연봉</td>                    
                </tr>
                <tr v-for="(emp, index) in emps" :key="index">
                    <td v-text="emp.id"></td>
                    <td>  <router-link :to="'search?id=' + emp.id">
                        {{emp.name}}</router-link>
                    </td>
                    <td v-text="emp.dept_name"></td>
                    <td v-text="emp.title"></td>
                    <td v-text="emp.salary"></td>
                </tr>
            </table>
        </div>
        <div v-else>
                <h3 class='text-center'>사원이 없습니다</h3>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            emps: [],
            src: [],
            sname: ''
        }
    },
    methods : {
        movePage : function(){
            this.$router.push('/add')
        },
        searchEmp : function(){
            if(this.sname != ''){
                this.emps = this.src.filter( emp => {
                    return this.sname == emp.empname
                })
            }
            else{
                this.emps = this.src;
            }
        }
    },
    created(){
        axios
            .get('http://localhost:8097/hrmboot/api/employee/all')
            .then(response => {
                this.emps = response.data;
                this.src = response.data;
            })
            .catch(error => {
                alert(error);
            });
    }
}
</script>

