export default {
    template: `  
    <p>
        <router-link to='/'>HOME</router-link>
        <br>
        <router-link to='/list'>사원 목록</router-link>
        <br>
        <router-link to='/add'>사원 등록</router-link>
    </p>
    `
}