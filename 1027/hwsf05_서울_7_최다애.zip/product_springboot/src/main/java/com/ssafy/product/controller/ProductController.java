package com.ssafy.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@ExceptionHandler
	public ModelAndView handler(Exception e) {
		ModelAndView mav = new ModelAndView("Error");
		mav.addObject("msg", e.getMessage());
		e.printStackTrace();
		return mav;
	}
	
	@GetMapping(value = "/listProduct.do", headers = { "Content-type=application/json" })
	public List<Product> listProduct() {
		return productService.searchAll();
	}

	@PostMapping(value = "/insertProduct.do", headers = { "Content-type=application/json" })
	public List<Product> insertProduct(@RequestBody Product product) {
		productService.insert(product);
		return productService.searchAll();
	}
	
	@GetMapping(value = "/searchProduct.do/{id}", headers = { "Content-type=application/json" })
	public Product searchProduct(@PathVariable("id") String id) {
		return productService.search(id);
	}
	
	@PutMapping(value = "/updateProduct.do", headers = { "Content-type=application/json" })
	public Product updateProduct(@RequestBody Product product) {
		productService.update(product);
		return productService.search(product.getId());
	}
	
	@DeleteMapping(value = "/removeProduct.do/{id}", headers = { "Content-type=application/json" })
	public List<Product> removeProduct(@PathVariable("id") String id) {
		productService.delete(id);
		return productService.searchAll();
	}
	
}









