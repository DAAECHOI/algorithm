package com.ssafy.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductSpringbootApplication.class, args);
	}

}
