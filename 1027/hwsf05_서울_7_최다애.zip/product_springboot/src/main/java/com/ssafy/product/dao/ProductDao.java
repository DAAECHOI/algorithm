package com.ssafy.product.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.product.dto.Product;

@Mapper
public interface ProductDao {
	public List<Product>  searchAll();
	public Product  search(String id);
	public void insert(Product product);
	public void update(Product product);
	public void delete(String id);
}
