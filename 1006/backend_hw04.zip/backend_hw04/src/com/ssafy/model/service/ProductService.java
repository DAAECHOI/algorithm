package com.ssafy.model.service;

import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductService {
	public Product getProduct(int productno) throws Exception;
	public int insertProduct(Product productDto) throws Exception;
	public List<Product> listProduct(String key, String word) throws Exception;
	void deleteProduct(int productno) throws Exception;
}
