package com.ssafy.model.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dao.ProductDao;
import com.ssafy.model.dao.ProductDaoImpl;
import com.ssafy.model.dto.Product;
import com.ssafy.util.DBUtil;

public class ProductServiceImpl implements ProductService {
	
	private ProductDao productDao;
	
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}
	
	@Override
	public Product getProduct(int productno) throws Exception {
		return productDao.getProduct(productno);
	}
	
	public int insertProduct(Product productDto) throws Exception {
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			productDao.insertProduct(conn,productDto);
			return productDao.getLastNo(conn);
		} catch (SQLException e) {
			DBUtil.rollback(conn);
			throw new Exception("제품 등록 중 오류 발생");
		} finally {
			DBUtil.close(conn);
		}
	}

	@Override
	public List<Product> listProduct(String key, String word) throws Exception {
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		return productDao.listProduct(key, word);
	}

	@Override
	public void deleteProduct(int productno) throws Exception {
		productDao.deleteProduct(productno);
	}

}
