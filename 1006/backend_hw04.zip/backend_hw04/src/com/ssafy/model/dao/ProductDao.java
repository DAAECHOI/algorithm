package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductDao {

	public int getLastNo(Connection conn) throws SQLException;
	public Product getProduct(int productno) throws SQLException;
	public void insertProduct(Connection conn,Product productDto) throws SQLException;
	public List<Product> listProduct(String key, String word) throws SQLException;
	public void deleteProduct(int productno) throws SQLException;
}
