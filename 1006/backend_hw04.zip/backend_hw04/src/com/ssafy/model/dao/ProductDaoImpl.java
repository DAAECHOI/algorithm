package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.util.DBUtil;

public class ProductDaoImpl implements ProductDao {
	
	public int getLastNo(Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql =" select LAST_INSERT_ID() as id from dual";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt("id");
			}else {
				throw new SQLException("ID 추출 오류");
			}
		}finally {
			DBUtil.close(pstmt);
		}
		
	}
	@Override
	public Product getProduct(int productno) throws SQLException {
		Product productDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			
			sql.append(" select * \n");
			sql.append(" from product \n");
			sql.append(" where productno = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, productno);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				productDto = new Product();
				productDto.setProductno(rs.getInt("productno"));
				productDto.setName(rs.getString("name"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setInfo(rs.getString("info"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return productDto;
	} 

	@Override
	public void insertProduct(Connection conn, Product product) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into product (name, price, info) \n");
			insertMember.append("values(?, ?, ?)");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, product.getName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getInfo());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
		}

	}
	@Override
	public List<Product> listProduct(String key, String word) throws SQLException {
		List<Product> list = new ArrayList<Product>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, name, price, info \n");
			sql.append("from product \n");
			if(!word.isEmpty()) {
				if("name".equals(key)) {
					sql.append("where name like ? \n");
				} else {
					sql.append("where " + key + " <= ? \n");
				}
			}
			sql.append("order by productno desc \n");
			pstmt = conn.prepareStatement(sql.toString());
			if(!word.isEmpty()) {
				if("name".equals(key))
					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, word);
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setProductno(rs.getInt("productno"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setInfo(rs.getString("info"));
				
				list.add(product);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

	@Override
	public void deleteProduct(int productno) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from product \n");
			insertMember.append("where productno = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setInt(1, productno);
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

}
